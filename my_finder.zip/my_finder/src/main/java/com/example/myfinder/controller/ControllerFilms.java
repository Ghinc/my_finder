package com.example.myfinder.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class ControllerFilms {

    @Autowired
    RestTemplate restTemplate;

    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Suceess|OK"),
            @ApiResponse(code = 401, message = "pas autorisé!"),
            @ApiResponse(code = 403, message = "Non!!!"),
            @ApiResponse(code = 404, message = "not found!!!") })

    @RequestMapping(value = "/getFilms", method = RequestMethod.GET)
    @HystrixCommand(fallbackMethod = "fallbackMethodStr")
    public String getFilmByDate(@PathVariable String date)
    {
        System.out.println("Getting films pour date " + date);

        String response = restTemplate.exchange("http://my-film/findFilmByDate/{date}",
                HttpMethod.GET, null, new ParameterizedTypeReference<String>() {}, date).getBody();

        System.out.println("Response Body " + response);

        return "Films à la date  " + date + " sont " + response+" ]";
    }

    @RequestMapping(value = "/getFilmByTitre", method = RequestMethod.GET)
    @HystrixCommand(fallbackMethod = "fallbackMethodStr")
    public String getFilmByTitre(@PathVariable String titre)
    {
        System.out.println("Getting film ayant pour titre " + titre);

        String response = restTemplate.exchange("http://my-film/findFilmByTitre/{titre}",
                HttpMethod.GET, null, new ParameterizedTypeReference<String>() {}, titre).getBody();

        System.out.println("Response Body " + response);

        return "Film ayant pour titre  " + titre + " : " + response ;
    }

    @ApiOperation(value = "Get all films ", response = String.class, tags = "getFilms")
    @HystrixCommand(fallbackMethod = "fallbackMethodVide")
    public String getFilms()
    {
        System.out.println("Getting all films");

        String response = restTemplate.exchange("http://my-film/getFilms",
                HttpMethod.GET, null, new ParameterizedTypeReference<String>() {}).getBody();

        System.out.println("Response Body " + response);

        return "Tous les films : " + response ;
    }

    @ApiOperation(value = "Get all actors ", response = String.class, tags = "getActors")
    @HystrixCommand(fallbackMethod = "fallbackMethodVide")
    public String getActors()
    {
        System.out.println("Getting all actors");

        String response = restTemplate.exchange("http://my-film/getActors",
                HttpMethod.GET, null, new ParameterizedTypeReference<String>() {}).getBody();

        System.out.println("Response Body " + response);

        return "Tous les acteurs : " + response ;
    }

    @RequestMapping(value = "/getActorByNom", method = RequestMethod.GET)
    @HystrixCommand(fallbackMethod = "fallbackMethodStr")
    public String getFActorByNom(@PathVariable String nom)
    {
        System.out.println("Getting actors whose name is " + nom);

        String response = restTemplate.exchange("http://my-film/getActorByNom/{nom}",
                HttpMethod.GET, null, new ParameterizedTypeReference<String>() {}, nom).getBody();

        System.out.println("Response Body " + response);

        return  response ;
    }

    @RequestMapping(value = "/getActorByFilm", method = RequestMethod.GET)
    @HystrixCommand(fallbackMethod = "fallbackMethodStr")
    public String getFActorByNom(@PathVariable String film)
    {
        System.out.println("Getting actors who had a part in film " + film);

        String response = restTemplate.exchange("http://my-film/getActorByFilm/{film}",
                HttpMethod.GET, null, new ParameterizedTypeReference<String>() {}, film).getBody();

        System.out.println("Response Body " + response);

        return  response ;
    }

    public String  fallbackMethod(int employeeid){

        return "Fallback response:: No film details available temporarily";
    }

    public String fallBackMethodVide(){
        return "Fallback response:: No film details available temporarily";
    }
    public String fallBackMethodStr(String chaine){
        return "Fallback response:: No film details available temporarily";
    }

    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
