package com.example.myfinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
